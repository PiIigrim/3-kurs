X = [(4, 8, 13, 7), (11, 4, 5, 14)]

# X = [np.mean(i) for i in X]
# #make covariance matrix
# X = np.array([i for i in X])
# print(X)
# cov = np.cov(X, bias=True)
# print(cov)